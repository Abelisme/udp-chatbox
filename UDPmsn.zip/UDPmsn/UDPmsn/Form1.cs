﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Threading;
using System.Net.Sockets;//匯入網路插座的相關訊息

namespace UDPmsn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        UdpClient U;
        Thread Th;
        private void button1_Click(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            Th = new Thread(Listen);
            Th.Start();
            button1.Enabled = false;//使按鍵失效，不能(也不需要)重複開啟
        }
        //監聽副程式
        private void Listen()
        {
            int Port = int.Parse(textBox1.Text);
            U = new UdpClient(Port);//建立UDP監聽器實驗
            //建立本機端點資訊
            IPEndPoint EP = new IPEndPoint(IPAddress.Parse("127.0.0.1"),Port);
            while(true)
            {
                byte[] B = U.Receive(ref EP);//訊息到達時讀取訊息到B陣列
                textBox2.Text = Encoding.Default.GetString(B);//翻譯陣列為字串
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
